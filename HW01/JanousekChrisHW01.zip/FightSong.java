/*
    Chris Janousek
	 CS210 Assignment HW1 #12
    1/11/2018
*/

public class FightSong {
  public static void main(String[] args){
    go();
    System.out.println();
    go();
    best();
    go();
    System.out.println();
    go();
    best();
    go();
    System.out.println();
    go();
  }

  public static void go(){
    System.out.println("Go, team, go!");
    System.out.println("You can do it.");
  }

  public static void best(){
    System.out.println("You're the best,");
    System.out.println("in the West.");
  }
}
