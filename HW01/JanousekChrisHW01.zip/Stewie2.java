/*
    Chris Janousek
	 CS210 Assignment HW1 #8
    1/11/2018
*/

public class Stewie2 {
  public static void main(String[] args){
    backSlash();
    for(int i = 1; i < 6;i++){
    text();
    frontSlash();
    }
  }

  public static void backSlash(){
    System.out.println("//////////////////////");
  }

  public static void text(){
    System.out.println("|| Victory is mine! ||");
  }

  public static void frontSlash(){
    System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
  }

}
