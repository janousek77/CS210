/*
    Chris Janousek
	 CS210 Assignment HW1 #3
    1/11/2018
*/

public class WellFormed {
  public static void main(String[] args){
    System.out.println("A well-formed Java program has");
    System.out.println("a main method with { and }");
    System.out.println("braces.");
    System.out.println();
    System.out.println("A System.out.println statement");
    System.out.println("has ( and ) and usually a");
    System.out.println("String that starts and ends");
    System.out.println("with a \" character");
    System.out.println("(But we type \\\" instead!)");

    // System.out.println("A well-formed Java program has\na main method with { and }\nbraces.\n\nA System.out.println statement\nhas ( and ) and usually a\nString that starts and ends\nwith a \" character\n(But we type \\\" instead!)");
  }
}
