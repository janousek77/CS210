/*
    Chris Janousek
	 CS210 Assignment HW1 #7
    1/11/2018
*/

public class Mantra{
  public static void main(String[] args){
    first();
    System.out.println();
    first();
  }

  public static void first(){
    System.out.println("There is one thing every coder must understand:");
    System.out.println("The System.out.println command.");
  }
}
