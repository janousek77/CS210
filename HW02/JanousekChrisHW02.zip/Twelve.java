/*
    Chris Janousek
	 CS210 Assignment HW02 #12
    1/18/2018
*/

public class Twelve {
  public static void main(String[] args) {
    for (int i = 0; i < 3; i++ ) {
      for (int j = 1; j < 10; j++) {
        for (int k = 1; k < 4; k++) {
          System.out.print(j);
        }
      }
      System.out.println();
    }
  }
}
