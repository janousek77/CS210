/*
    Chris Janousek
	 CS210 Assignment HW02 #7
    1/18/2018
*/

public class Seven {
  public static void main(String[] args) {
    for (int i = 1; i < 6; i++) {
      for (int j = 5; j > i; j--) {
        System.out.print(" ");
      }
      System.out.println(i);
    }
  }
}
