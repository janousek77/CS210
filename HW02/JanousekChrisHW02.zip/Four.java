/*
    Chris Janousek
	 CS210 Assignment HW02 #4
    1/18/2018
*/

public class Four {

  public static void main(String[] args) {
    for (int i = 0; i < 4; i++ ) {
      for (int j = 0; j < 5 ;j++) {
        System.out.print("*");
      }
      System.out.println();
    }
  }
}
